

WonkoBook:Android matt$ svn ps svn:keywords "author date id revision" Fl_Android_Application.*
property 'svn:keywords' set on 'Fl_Android_Application.cpp'
property 'svn:keywords' set on 'Fl_Android_Application.h'
WonkoBook:Android matt$ svn pg svn:eol-style Fl_Font.H 
native
WonkoBook:Android matt$ svn ps svn:eol-style "native" Fl_Android_Application.*
property 'svn:eol-style' set on 'Fl_Android_Application.cpp'
property 'svn:eol-style' set on 'Fl_Android_Application.h'


